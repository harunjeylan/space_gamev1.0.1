#THIS SIMPLE HUBO ON GALAXY GAME IS MADE BY HARUN JEYLAN 
#ASTU 2-YEAR ELECTONICS AND COMUNICATION-ENGINEERING 
# 22/jun/2022 EC
# space game v-1.0.1

#===========IMPORTIMG=============
import pygame, sys, os
from pygame.locals import *
import numpy as np
import random
import webbrowser
from source import mydb
#========================
pygame.init() #INIT PYGAME

#===========CONSTANT=============
WIDTH = 480 #width of window
HEIGHT = 800 #hight of window
FPS = 80 #Defalt 80
MIN_SPEED_Y = 5 #Defalt 5
MAX_SPEED_Y = 15 #Defalt 15
SPEED_X = 50 #Defalt 50
SCORE_MALT = 1 #Defalt 1
SCORE_DUR = 5 #Defalt 5
LAVEL_DUR = 100 #Defalt 100


#==================SETTING ===================
#===========GET SETTING FROM DATABASE=========
setting = mydb.getSetting()
BRIDG_MAXWIDTH  = setting["brWidth"]
BRIDGHEIGHT  = setting["brHeith"]
BRIDG_NUM = setting["brNum"]

SHOW_HOR_LINE  = setting["horLine"]
USE_SOUND   = setting["sound"]
#USE_MUSIC = setting["music"]
USE_BG_IMG  = setting["bgImg"]

#===========SET SETTING==============
#BRIDG_MAXWIDTH = 150 #Defalt 150
#BRIDGHEIGHT = 50 #Defalt 50
#BRIDG_NUM = 9 #Defalt 9

#SHOW_HOR_LINE =False #Defalt False
#USE_SOUND = True #Defalt True
#USE_MUSIC = True #Defalt True
#USE_BG_IMG = True #Defalt True

#===========FONT SIZE=========
BASICFONTSIZE = 20
BUTTONFONTSIZE = 30
TITLEFONTSIZE = 50
NORMALFONTSIZE = 25
#========================

#======COLORS========
WHITE = (255,255,255)
GREEN = (0,255,0)
BLUE = (0,0,255)
RED = (255,0,0)
BLACK = (0,0,0)
YELLOW = (255, 255, 0)
BRIGHTBLUE =  (  0,  50, 255)
DARKTURQUOISE = (  3,  54,  73)

def rondomColorpicker():
    r = random.randint(50,255)
    g = random.randint(50,255)
    b = random.randint(50,255)
    return np.array([r,g,b], dtype=np.int32)
    
COLORS = np.array([rondomColorpicker() for i in range(100)], dtype=np.int32)
TILECOLOR = GREEN
TEXTCOLOR = WHITE
BUTTONCOLOR = WHITE
BGCOLOR = DARKTURQUOISE
BACKGROUND = pygame.image.load(os.path.join('image','bg1.jpg'))
#========================================

#=========== VOICE =========
galaxy_voice = pygame.mixer.Sound(os.path.join('sound','galaxy.wav'))
gameover_voice = pygame.mixer.Sound(os.path.join('sound','gameover_voice.wav'))
begin_voice = pygame.mixer.Sound(os.path.join('sound','begin.wav'))
restart_voice = pygame.mixer.Sound(os.path.join('sound','restart.wav'))
#========================================

#===========SETUPING=========
WIN = pygame.display.set_mode((WIDTH,HEIGHT))
pygame.display.set_caption('my game')

def setup():
    global CENTER_WIN_X, CENTER_WIN_Y, INITIAL_POINT_X, INITIAL_POINT_Y
    global POS_POINT_LIST_X, ACTIVE_BRIDG_POINT,CLOCK
    global WIDTH, HEIGHT, INITIAL_POINT_Y, BRIDG_NUM, BRIDG_MAXWIDTH, BRIDGHEIGHT, SPEED_X
    
    CLOCK = pygame.time.Clock()
    
    CENTER_WIN_X = WIDTH//2 + WIDTH%2
    CENTER_WIN_Y = HEIGHT//2 + HEIGHT%2
    INITIAL_POINT_X = CENTER_WIN_X
    INITIAL_POINT_Y = HEIGHT//4

    initial = 0 - (BRIDG_MAXWIDTH * BRIDG_NUM - WIDTH)/2
    final = WIDTH + (BRIDG_MAXWIDTH * BRIDG_NUM - WIDTH)/2
    POS_POINT_LIST_X = np.linspace(initial, final,BRIDG_NUM+1, dtype=np.int32)
    ACTIVE_BRIDG_POINT = POS_POINT_LIST_X[BRIDG_NUM//2]
    while (HEIGHT - INITIAL_POINT_Y) % BRIDGHEIGHT != 0:
        BRIDGHEIGHT -= 1
    while BRIDG_MAXWIDTH % SPEED_X != 0:
        SPEED_X -= 1
#========================================

#==============GAME BACK END========================

#========================================            
def directionEventHandeler(context):    
    for event in pygame.event.get():
        if event == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == MOUSEBUTTONUP:
            if event.pos[0] >  CENTER_WIN_Y  and context["point"] < BRIDG_NUM -1:
                context["point"]  += 1
            elif event.pos[0] < CENTER_WIN_Y   and context["point"] > 0:
                context["point"]  -= 1                           
    return  context["point"] 
#========================================

#===========MAIN FUNCTION=========
def main():
    global CENTER_WIN_X, CENTER_WIN_Y, INITIAL_POINT_X, INITIAL_POINT_Y
    global POS_POINT_LIST_X, ACTIVE_BRIDG_POINT
    
    SPEED = MIN_SPEED_Y
    
    point  = BRIDG_NUM//2
    active = True
    SCORE = [0, 0]
    LAVEL = 1
    PosX = np.array([BRIDG_NUM//2, BRIDG_NUM//2+1], dtype=np.int32)
    line_list_y = np.arange(INITIAL_POINT_Y, HEIGHT + (BRIDGHEIGHT * 4), BRIDGHEIGHT, dtype=np.int32)
    BRIDG_LIST = [Bridg() for i in range(len(line_list_y))]
    intialbridge = Bridg()
    intialbridge.setBridg(PosX, (INITIAL_POINT_Y, HEIGHT))
    intialbridge.PosX = PosX
    #---------- main loop ---------------
    while True:
        pygame.display.update()
        CLOCK.tick(FPS)
        draw_window()
        textSurf, textRect = makeText(f"LAVEL: {LAVEL}; SCORE: {SCORE[0]}", {'font_size': BASICFONTSIZE, 'xpos':10 , 'ypos': 10})
        WIN.blit(textSurf, textRect)
        point = directionEventHandeler({'point': point})
        pygame.event.clear()
        if POS_POINT_LIST_X[point] < ACTIVE_BRIDG_POINT:
            POS_POINT_LIST_X += SPEED_X
        elif POS_POINT_LIST_X[point] > ACTIVE_BRIDG_POINT:
            POS_POINT_LIST_X -= SPEED_X
        
        ind1 = line_list_y < HEIGHT + BRIDGHEIGHT * 4        
        ind2 = line_list_y >= HEIGHT + BRIDGHEIGHT * 4
        line_list_y[ind2] =  INITIAL_POINT_Y
        line_list_y[ind1] +=  SPEED 
        
        BRIDG_LIST, intialbridge, active, PosX = createBridge(BRIDG_LIST, line_list_y, intialbridge, active, PosX)
        
        if SHOW_HOR_LINE:
            for i in range(len(line_list_y)):
                y = line_list_y[i]
                point1 = calculatePointXY(POS_POINT_LIST_X[0], y)
                point2 = calculatePointXY(POS_POINT_LIST_X[-1], y)
                pygame.draw.line(WIN, WHITE, point1, point2, 1)
            
        for x in POS_POINT_LIST_X:
            pygame.draw.line(WIN, WHITE, (INITIAL_POINT_X, INITIAL_POINT_Y), (x,HEIGHT), 1)
        
        pygame.draw.polygon(WIN, BLACK, ((INITIAL_POINT_X, HEIGHT-100-5), (INITIAL_POINT_X+25+5, HEIGHT-50+5), (INITIAL_POINT_X-25-5, HEIGHT-50+5)))
        if active:
            pygame.draw.polygon(WIN, WHITE, ((INITIAL_POINT_X, HEIGHT-100), (INITIAL_POINT_X+25, HEIGHT-50), (INITIAL_POINT_X-25, HEIGHT-50)))            
            SPEED += SCORE[0]//(LAVEL_DUR * LAVEL) if SPEED <= MAX_SPEED_Y else 0
            LAVEL += SCORE[0]//(LAVEL_DUR * LAVEL)
            SCORE[1] += 1
            
            if SCORE[1] >= SCORE_DUR:
                SCORE[0] +=  SCORE_MALT
                SCORE[1] = 0
        else:
           pygame.draw.polygon(WIN, RED, ((INITIAL_POINT_X, HEIGHT-100), (INITIAL_POINT_X+25, HEIGHT-50), (INITIAL_POINT_X-25, HEIGHT-50)))  
           return SCORE[0]
           break
#========================================

#==================DROWING WINDOW=================
def draw_window():   
    if USE_BG_IMG:
        WIN.blit(BACKGROUND, (0, 0))
    else:
        WIN.fill(BGCOLOR)
#========================================

#========================================    
def calculatePointXY(PosPointX, PointY):
    exactPoint = np.array([0, PointY], dtype=np.int32)
    if PosPointX < CENTER_WIN_X:
        exactPoint[0] =  INITIAL_POINT_X-((INITIAL_POINT_X - PosPointX)*(PointY-INITIAL_POINT_Y)/(HEIGHT-INITIAL_POINT_Y))
    else:
        exactPoint[0] =  INITIAL_POINT_X+((PosPointX-INITIAL_POINT_X)*(PointY-INITIAL_POINT_Y)/(HEIGHT-INITIAL_POINT_Y))
    return exactPoint
#========================================

#========================================    
def chengePosX(PosX):
    if PosX[0] ==  0 and PosX[1] ==  1:
        PosX =  random.choice([PosX, PosX + 1])
    elif PosX[0] ==  BRIDG_NUM-1 and PosX[1] ==  BRIDG_NUM:
        PosX =  random.choice([PosX-1, PosX])
    else:
        PosX =  random.choice([PosX - 1, PosX, PosX + 1])
    return PosX
#========================================

#========================================     
def exactPointXY(PosX, exactPointY):  
    exactPoints = np.zeros((4, 2), dtype = np.int32)
    posPoint_x1 = POS_POINT_LIST_X[PosX[0]]
    posPoint_x2 = POS_POINT_LIST_X[PosX[1]]
    exactPoints[0] = calculatePointXY(posPoint_x1, exactPointY[0])
    exactPoints[1] = calculatePointXY(posPoint_x2, exactPointY[0])
    exactPoints[2] = calculatePointXY(posPoint_x2, exactPointY[1])
    exactPoints[3] = calculatePointXY(posPoint_x1, exactPointY[1])
    return exactPoints
#========================================

#===============BRIDG CLASS=================    
class Bridg:
    def __init__(self):
        self.points = np.zeros((4, 2),  dtype=np.int32)
        self.color = (0,200,100)
        self.PosX = np.array([0,0],  dtype=np.int32)    
    def setBridg(self, PosX, exactPointY):  
        self.PosX = chengePosX(PosX)
        self.points  = exactPointXY(self.PosX, exactPointY)
        colorIndex = random.randint(0,len(COLORS)-1)
        self. color = COLORS[colorIndex]
        return  self.PosX
    def updateBridg(self, exactPointY):
        self.points = exactPointXY(self.PosX, exactPointY)
    def getPoints(self):
        return self.points
    def getColor(self):
         return  self.color 
#========================================

#========================================                         
def createBridge(BRIDG_LIST, line_list_y, intialbridge, active, PosX):
        active = False
        for i in range(len(BRIDG_LIST)):            
            if line_list_y[i] == INITIAL_POINT_Y and i%2==1:
                 PosX =  BRIDG_LIST[i].setBridg(PosX, (INITIAL_POINT_Y, INITIAL_POINT_Y))
            elif line_list_y[i-3] > line_list_y[i]: 
                 BRIDG_LIST[i].updateBridg((INITIAL_POINT_Y, line_list_y[i]))
            else:
                 BRIDG_LIST[i].updateBridg((line_list_y[i-3] , line_list_y[i]))

            points = BRIDG_LIST[i].getPoints()
            color = BRIDG_LIST[i].getColor()
            if intialbridge.getPoints()[0,1] < HEIGHT and i==0:
                if BRIDG_LIST[0].getPoints()[3,1] <= INITIAL_POINT_Y + BRIDGHEIGHT*2:
                    intialbridge.updateBridg((INITIAL_POINT_Y , HEIGHT))
                else:
                    intialbridge.updateBridg((line_list_y[-2] , HEIGHT))                
                points = intialbridge.getPoints()
                                  
            polygon = pygame.draw.polygon(WIN, color, points)        
            if polygon.collidepoint(INITIAL_POINT_X, HEIGHT-75) or polygon.collidepoint(INITIAL_POINT_X, HEIGHT-50):
                 active = True              
                 
        return BRIDG_LIST, intialbridge, active, PosX
#========================================

#========================================
def setCenter(myRect, xPos, yPos):
    myRect.centery = yPos
    myRect.centerx = xPos
#========================================

#========================================        
def makeText(text, style):     
     color = style['color'] if 'color' in style else TEXTCOLOR
     bg_color = style['bg_color'] if 'bg_color' in style else None
     font_size = style['font_size'] if 'font_size' in style else NORMALFONTSIZE
     xpos = style['xpos'] if 'xpos' in style else 0
     ypos = style['ypos'] if 'ypos' in style else 0
     center = style['center'] if 'center' in style else False
     
     BASICFONT = pygame.font.Font(os.path.join('source','freesansbold.ttf'), font_size)
     textSurf = BASICFONT.render(text, True, color, bg_color)
     textRect = textSurf.get_rect()
     if center:
        textRect.centerx, textRect.centery = xpos, ypos
     else:
        textRect.topleft = (xpos, ypos)
     return (textSurf, textRect)
#========================================



#==================GAME FROM END====================

#=================MY EVENTS=======================
GAMEHOME = "GAMEHOME"
START = "START"
RESTART = "RESTART"
SETTING = "SETTING"
UPDATE = "UPDATE"
CONTACT = "CONTACT"
ABOUT = "ABOUT"
SAVE = "SAVE"
BACK = "BACK"
EXIT = "EXIT"
#========================================

#========================================        
def gameHomePage(subTitle, startGame, newScore=None):
    draw_window()
    highScore = mydb.getScore()
    highScore =  highScore if highScore != None else 0
    #makeText(f"GALAXY", {'color':TILECOLOR, 'font_size':TITLEFONTSIZE, 'xpos': CENTER_WIN_X, 'ypos': INITIAL_POINT_Y + 60, 'center': True})
    titleSerf, titleRect = makeText(f"GALAXY", {'color':TILECOLOR, 'font_size':TITLEFONTSIZE, 'xpos': CENTER_WIN_X, 'ypos': INITIAL_POINT_Y, 'center': True})
    pygame.draw.line(WIN, WHITE, (50, INITIAL_POINT_Y+40), (WIDTH-50,INITIAL_POINT_Y+40), 1)
    haghScoreSurf, haghScoreRect = makeText(f"HIGH SCORE: {highScore}", {'xpos': CENTER_WIN_X , 'ypos': INITIAL_POINT_Y+80, 'center': True })
    
    subTitleSerf, subTitleRect = makeText(f"{subTitle}", {'color':TILECOLOR, 'xpos': CENTER_WIN_X, 'ypos': CENTER_WIN_Y -60, 'center': True})
    scoreSerf, scoreRect = makeText(f"YOUR SCORE: {newScore}", {'xpos': CENTER_WIN_X , 'ypos': CENTER_WIN_Y, 'center':  True})
    startGameSerf, startGameRect = makeText(f"{startGame}", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE, 'xpos': CENTER_WIN_X , 'ypos' : CENTER_WIN_Y + 60, 'center':  True})
    
    pygame.draw.line(WIN, WHITE, (50, CENTER_WIN_Y+200), (WIDTH-50,CENTER_WIN_Y+200), 1)    
    aboutSerf, aboutRect = makeText(f"about", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE, 'xpos':CENTER_WIN_X - 150  , 'ypos': CENTER_WIN_Y+240, 'center': True  }) 
    settSerf, settRect = makeText(f"setting", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE, 'xpos':CENTER_WIN_X, 'ypos': CENTER_WIN_Y+240, 'center': True }) 
    quitSerf, quitRect = makeText("quit", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE, 'xpos':CENTER_WIN_X + 150 , 'ypos': CENTER_WIN_Y+240, 'center': True })
    
    WIN.blit(titleSerf, titleRect)
    WIN.blit(subTitleSerf, subTitleRect)
    WIN.blit(haghScoreSurf, haghScoreRect)
    if newScore is not None: WIN.blit(scoreSerf, scoreRect)
    WIN.blit(startGameSerf, startGameRect)
    
    WIN.blit(startGameSerf, startGameRect)
    WIN.blit(settSerf, settRect)
    
    WIN.blit(aboutSerf, aboutRect)
    WIN.blit(quitSerf, quitRect)
    pygame.display.update()
    context = {
            'start_rect': startGameRect, 
            'settRect' : settRect,
            'aboutRect':aboutRect,
            'quit_rect' : quitRect,
        }
    return context
#========================================

#========================================        
def settingEventHandeler(context, gamesetting):
    for event in pygame.event.get():
        if event.type == MOUSEBUTTONUP:                 
            if context["saveRect"].collidepoint(event.pos):
                 return SAVE, gamesetting
            elif context["backRect"].collidepoint(event.pos):
                 return BACK, gamesetting 
            elif pygame.QUIT in pygame.event.get():
                 pygame.quit()
                 sys.exit()       
            elif context["horLineButton"].collidepoint(event.pos):
                 gamesetting['horLine'] = not gamesetting['horLine']
                 return UPDATE, gamesetting
            elif context["bgColorButton"].collidepoint(event.pos):
                 gamesetting["bgImg"] = not gamesetting["bgImg"]
                 return UPDATE, gamesetting
            elif context["soundButton"].collidepoint(event.pos):
                 gamesetting["sound"] = not gamesetting["sound"]
                 return UPDATE, gamesetting
            elif context["musicButton"].collidepoint(event.pos):
                 gamesetting["music"] = not gamesetting["music"]
                 return UPDATE, gamesetting
           
            elif context["brWidthButtonSub"].collidepoint(event.pos):
                 if gamesetting["brWidth"] > 100:
                     gamesetting["brWidth"] -= 5
                 return UPDATE, gamesetting
            elif context["brHeithButtonSub"].collidepoint(event.pos):
                 if gamesetting["brHeith"] > 50:
                     gamesetting["brHeith"] -= 5
                 return UPDATE, gamesetting
            elif context["brNumButtonSub"].collidepoint(event.pos):
                 if gamesetting["brNum"] > 3:
                     gamesetting["brNum"] -= 2
                 return UPDATE, gamesetting       
                 
            elif context["brWidthButtonPlus"].collidepoint(event.pos):
                 if gamesetting["brWidth"] < 200:
                     gamesetting["brWidth"] += 5
                 return UPDATE, gamesetting
            elif context["brHeithButtonPlus"].collidepoint(event.pos):
                 if gamesetting["brHeith"] < 100:
                     gamesetting["brHeith"] += 5
                 return UPDATE, gamesetting
            elif context["brNumButtonPlus"].collidepoint(event.pos):
                 if gamesetting["brNum"] < 15:
                     gamesetting["brNum"] += 2
                 return UPDATE, gamesetting
            elif context["reHsButton"].collidepoint(event.pos):
                 gamesetting["hscore"] = 0
                 return UPDATE, gamesetting
                 
    return None, gamesetting
#========================================

#========================================        
def saveSetting(gamesetting):
    global SHOW_HOR_LINE, USE_BG_IMG, USE_SOUND
    global BRIDG_MAXWIDTH, BRIDGHEIGHT, BRIDG_NUM
    
    SHOW_HOR_LINE = gamesetting['horLine']
    USE_BG_IMG = gamesetting['bgImg']
    USE_SOUND = gamesetting['sound']
            
    BRIDG_MAXWIDTH = gamesetting["brWidth"]
    BRIDGHEIGHT = gamesetting["brHeith"]
    BRIDG_NUM = gamesetting["brNum"]
            
    settingContext = mydb.getSetting()
    settingContext["horLine"] = SHOW_HOR_LINE
    settingContext["sound"] = USE_SOUND
    settingContext["bgImg"] = USE_BG_IMG 
            
    settingContext["brWidth"] = BRIDG_MAXWIDTH
    settingContext["brHeith"] = BRIDGHEIGHT
    settingContext["brNum"] = BRIDG_NUM         
    mydb.updateSetting(settingContext)
 #========================================

#========================================        
def setting(gamesetting):
    draw_window()
    titleSerf, titleRect = makeText(f"SETTING", {'color':TILECOLOR, 'font_size':TITLEFONTSIZE, 'xpos': CENTER_WIN_X, 'ypos': INITIAL_POINT_Y - 100,'center': True})
    pygame.draw.line(WIN, WHITE, (10, INITIAL_POINT_Y - 60), (WIDTH-10,INITIAL_POINT_Y - 60), 1)
    
    offon = lambda cond: "ON" if not cond else "OFF"
    hscore = lambda : "RESET" if gamesetting['hscore'] > 0 else "RESETED"
    
    horLineText, horLineButton = [makeText("HORISONTAL LINE", {'xpos': 10 , 'ypos': CENTER_WIN_Y - 240}),
                                                        makeText(offon(gamesetting['horLine']), {'xpos': CENTER_WIN_X + 100 , 'ypos': CENTER_WIN_Y - 240})
                                                        ] 
    bgColorText, bgColorButton = [makeText("BACKGROUND IMAGE", {'xpos': 10 , 'ypos': CENTER_WIN_Y - 180}),
                                                        makeText(offon(gamesetting['bgImg']), {'xpos': CENTER_WIN_X + 100 , 'ypos': CENTER_WIN_Y - 180})
                                                        ]
    soundText, soundButton = [makeText("SOUND", {'xpos': 10 , 'ypos': CENTER_WIN_Y - 120}),
                                                        makeText(offon(gamesetting['sound']), {'xpos': CENTER_WIN_X + 100 , 'ypos': CENTER_WIN_Y - 120})
                                                        ]
    musicText, musicButton = [makeText("MUSIC", {'xpos': 10 , 'ypos': CENTER_WIN_Y - 60}),
                                                        makeText(offon(gamesetting['music']), {'xpos': CENTER_WIN_X + 100 , 'ypos': CENTER_WIN_Y - 60})
                                                        ]
    brWidthText, brWidthButtonSub, brWidthLab, brWidthButtonPlus = [makeText("BRIDG WIDTH", {'xpos': 10 , 'ypos': CENTER_WIN_Y}),
                                                        makeText("-", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE+10,'xpos': CENTER_WIN_X + 60 , 'ypos': CENTER_WIN_Y - 10}),
                                                        makeText(f"{gamesetting['brWidth']}", {'xpos': CENTER_WIN_X + 95 , 'ypos': CENTER_WIN_Y}),
                                                        makeText("+", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE+10, 'xpos': CENTER_WIN_X + 160 , 'ypos': CENTER_WIN_Y - 10}),
                                                        ]
    brHeithText, brHeithButtonSub, brHeithLab, brHeithButtonPlus = [makeText("BRIDG HEIGHT", {'xpos': 10 , 'ypos': CENTER_WIN_Y + 60}),
                                                        makeText("-", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE+10, 'xpos': CENTER_WIN_X + 60 , 'ypos': CENTER_WIN_Y + 50}),
                                                        makeText(f"{gamesetting['brHeith']}", {'xpos': CENTER_WIN_X + 105 , 'ypos': CENTER_WIN_Y + 60}),
                                                        makeText("+", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE+10, 'xpos': CENTER_WIN_X + 160 , 'ypos': CENTER_WIN_Y + 50}),
                                                        ]
    brNumText, brNumButtonSub, brNumLab, brNumButtonPlus = [makeText("BRIDG NUMBER", {'xpos': 10 , 'ypos': CENTER_WIN_Y + 120}),
                                                        makeText("-", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE+10, 'xpos': CENTER_WIN_X + 60 , 'ypos': CENTER_WIN_Y + 110}),
                                                        makeText(f"{gamesetting['brNum']}", {'xpos': CENTER_WIN_X + 105 , 'ypos': CENTER_WIN_Y + 120}),
                                                        makeText("+", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE+10, 'xpos': CENTER_WIN_X + 160 , 'ypos': CENTER_WIN_Y + 110}),
                                                        ] 
    reHsText, reHsButton = [makeText("RESERT HIGH SCORE", {'xpos': 10 , 'ypos': CENTER_WIN_Y + 180}),
                                                        makeText(f"{hscore()}", {'xpos': CENTER_WIN_X + 100 , 'ypos': CENTER_WIN_Y + 180})
                                                        ]
    pygame.draw.line(WIN, WHITE, (10, CENTER_WIN_Y+220), (WIDTH-10,CENTER_WIN_Y+220), 1)
    backSerf, backRect = makeText("BACK", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE, 'xpos': 10  , 'ypos':CENTER_WIN_Y+260})
    saveSerf, saveRect = makeText("SAVE", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE, 'xpos': 210  , 'ypos':CENTER_WIN_Y+260})
    
    items = [[titleSerf, titleRect],horLineText, horLineButton,bgColorText, bgColorButton, soundText, soundButton, musicText, musicButton ,
                    brWidthText, brWidthButtonSub, brWidthLab, brWidthButtonPlus, brHeithText, brHeithButtonSub, brHeithLab, brHeithButtonPlus,
                    brNumText, brNumButtonSub, brNumLab, brNumButtonPlus , [backSerf, backRect ], [saveSerf, saveRect],reHsText, reHsButton]

    for surf, rect in items:
        WIN.blit(surf, rect)
    
    pygame.display.update()
    context = {
            'backRect' : backRect,
            'saveRect': saveRect,
            'horLineButton' : horLineButton[1],
            'bgColorButton': bgColorButton[1],
            'soundButton' : soundButton[1],
            'musicButton' : musicButton[1],
            
            'brWidthButtonSub': brWidthButtonSub[1],
            'brHeithButtonSub' : brHeithButtonSub[1],
            'brNumButtonSub' : brNumButtonSub[1],
            
            'brWidthButtonPlus': brWidthButtonPlus[1],
            'brHeithButtonPlus' : brHeithButtonPlus[1],
            'brNumButtonPlus' : brNumButtonPlus[1],
            'reHsButton':reHsButton[1]
        }
    
    while True:
        CLOCK.tick(FPS)
        event, gamesetting = settingEventHandeler(context, gamesetting)
        pygame.event.clear()
        if event == SAVE:
            saveSetting(gamesetting)
            if gamesetting['hscore'] == 0: mydb.resetScore()
            break 
        if event == UPDATE:
            setting(gamesetting)
        if event == BACK:
            break
#========================================

#========================================            
def aboutEventHandeler(context):    
    for event in pygame.event.get():
        if event == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == MOUSEBUTTONUP:
            if context["webRect"].collidepoint(event.pos):
                 webbrowser.open("https://www.google.com")
            elif context["teleRect"].collidepoint(event.pos):
                 webbrowser.open("https://t.me/HarunJeylan")
            elif context["faceRect"].collidepoint(event.pos):
                 webbrowser.open("https://www.google.com")
            elif context["backRect"].collidepoint(event.pos):
                 return BACK
#========================================

#========================================        
def about():
    draw_window()
    titleSerf, titleRect = makeText(f"ABOUT", {'color':TILECOLOR, 'font_size':TITLEFONTSIZE, 'xpos': CENTER_WIN_X, 'ypos': INITIAL_POINT_Y, 'center': True})
    pygame.draw.line(WIN, WHITE, (50, INITIAL_POINT_Y+40), (WIDTH-50,INITIAL_POINT_Y+40), 1)
    nameSurf, nameRect = makeText(f"CREATE BY: HARUN JEYLAN", {'xpos': CENTER_WIN_X , 'ypos': CENTER_WIN_Y - 90, 'center':  True}) 
    addrSerf, addrRect = makeText(f"ADDRESS: ASTU ", {'xpos': CENTER_WIN_X , 'ypos': CENTER_WIN_Y - 30, 'center':  True}) 
    phoneSerf, phoneRect = makeText("PHONE-NO: 0922414657", {'xpos': CENTER_WIN_X , 'ypos': CENTER_WIN_Y + 30, 'center':  True})
    backSerf, backRect = makeText("BACK", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE, 'xpos':CENTER_WIN_X  , 'ypos':CENTER_WIN_Y+90, 'center': True })
    
    pygame.draw.line(WIN, WHITE, (50, CENTER_WIN_Y+150), (WIDTH-50,CENTER_WIN_Y+150), 1)
    webSurf, webRect = makeText(f"website", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE, 'xpos':CENTER_WIN_X-150 , 'ypos': CENTER_WIN_Y+190, 'center':True}) 
    teleSurf, teleRect = makeText(f"telegram", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE, 'xpos':CENTER_WIN_X , 'ypos': CENTER_WIN_Y+190, 'center':True}) 
    faceSurf, faceRect = makeText(f"facebook", {'color':BUTTONCOLOR, 'font_size':BUTTONFONTSIZE, 'xpos':CENTER_WIN_X +150, 'ypos': CENTER_WIN_Y+190, 'center':True}) 
    
    WIN.blit(titleSerf, titleRect)
    WIN.blit(nameSurf, nameRect)
    WIN.blit(addrSerf, addrRect)
    WIN.blit(phoneSerf, phoneRect)
    WIN.blit(backSerf, backRect)
    
    WIN.blit(webSurf, webRect )
    WIN.blit(teleSurf, teleRect)
    WIN.blit(faceSurf, faceRect)
    
    pygame.display.update()
    context = {
            'backRect' : backRect,
            'webRect':webRect,
            'teleRect':teleRect,
            'faceRect':faceRect
        }
    while True:
        CLOCK.tick(FPS)
        event = aboutEventHandeler(context)
        pygame.event.clear()
        if event == BACK:
            break
#========================================

#========================================        
def gameEventHandeler(context):
    for event in pygame.event.get():
        if event == pygame.QUIT:
            return EXIT
        if event.type == MOUSEBUTTONUP:
            if context["start_rect"].collidepoint(event.pos):
                 return START
            elif context["settRect"].collidepoint(event.pos):
                 return SETTING
            elif context["aboutRect"].collidepoint(event.pos):
                 return ABOUT
            elif context["quit_rect"].collidepoint(event.pos):
                return EXIT
            else:
                return GAMEHOME
#========================================

#========================================
if __name__=='__main__':
    setup()
    draw_window()
    if USE_SOUND:galaxy_voice.play()
    subTitle = "NEW GAME"
    newScore = None
    startGame = START
    while True:
        context = gameHomePage(subTitle, startGame, newScore)                    
        event = gameEventHandeler(context)
        pygame.event.clear()
        CLOCK.tick(FPS)
        if event == GAMEHOME:
            continue
        elif event == START:
            setup()
            if USE_SOUND:
                begin_voice.play() if startGame == START else restart_voice.play()            
            newScore = main()
            mydb.setScore(newScore)
            if USE_SOUND:gameover_voice.play()
            subTitle = "GAME OVER"      
            startGame = RESTART                  
        elif event == SETTING:
            gamesetting = {
                'horLine': SHOW_HOR_LINE,
                'bgImg': USE_BG_IMG,
                 'sound': USE_SOUND,
                 'music' : None,
                 'brWidth' : BRIDG_MAXWIDTH,
                 'brHeith': BRIDGHEIGHT,
                 'brNum':BRIDG_NUM,
                 'hscore': mydb.getScore()
            }
            setting(gamesetting)
        elif event == ABOUT:
            about()
        elif event == EXIT:
            pygame.quit()
            sys.exit()
            break