import sqlite3, os
#import pandas as pd
#=====CONNECTING WITH DATABASE=======
#conn = sqlite3.connect('student.db')
#c = conn.cursor()

#=========CREATING TABLE=========
def connect():
    if __name__ == '__main__':
        conn = sqlite3.connect(os.path.join('spaceGame.db'))
    else:
        conn = sqlite3.connect(os.path.join('source','spaceGame.db'))
    c = conn.cursor()
    return conn, c
    
def createGalaxyTable():
    conn, c = connect()
    c.execute("""CREATE TABLE galaxy (
                        horLine  boolian,
                        sound  boolien,
                        music boolien,
                        bgImg boolien,
                        brWidth int,
                        brHeith int,
                        brNum int
                         )
                    """)
    conn.commit()
    
def createScoreTable():
    conn, c = connect()
    c.execute("CREATE TABLE HighScore (highScore  int )")
    conn.commit()

#==========INSERTING SCORE===========
def insertScore(score):
    conn, c = connect()
    c.execute(f"INSERT INTO HighScore(highScore) values({score})")
    conn.commit()

def insertSetting(setting):
    horLine  = setting["horLine"]
    sound   = setting["sound"]
    music  = setting["music"]
    bgImg = setting["bgImg"]
    brWidth  = setting["brWidth"]
    brHeith  = setting["brHeith"]
    brNum  = setting["brNum"]
    conn, c = connect()
    c.execute(f"""INSERT INTO galaxy(horLine, sound, music,bgImg, brWidth, brHeith, brNum)
                                                    values({horLine}, {sound}, {music}, {bgImg},{brWidth}, {brHeith}, {brNum})""")
    conn.commit()
    
#==========GATING SCORE===========
def getSetting():
    conn, c = connect()
    x = c.execute("SELECT ROWID, * FROM galaxy")
    result = x.fetchone()
    if result == None:
        return None
    else:
        setting = {}
        setting["horLine"] = result[1]
        setting["sound"] = result[2]
        setting["music"] = result[3]
        setting["bgImg"] = result[4]
        setting["brWidth"] = result[5]
        setting["brHeith"] = result[6]
        setting["brNum"] = result[7]
        return setting
    
def getScore(*args, **kargs):
    conn, c = connect()
    x = c.execute("SELECT ROWID, * FROM HighScore")
    result = None
    #print(kargs)
    if args == () or args[0] == 1:
        result = x.fetchone()
    elif args[0] > 1:
        result = x.fetchmany(args[0])
    elif kargs['all'] == True:
        result = x.fetchall()
    conn.commit()
    return result[1]
    
#==========UPDATING SCORE===========
def updateScore(id, score):
    conn, c = connect()
    c.execute(f"UPDATE HighScore SET HighScore={score} WHERE ROWID={id}")
    conn.commit()
    
def updateSetting(setting):
    id = 1
    conn, c = connect()
    horLine  = setting["horLine"]
    sound   = setting["sound"]
    music  = setting["music"]
    bgImg  = setting["bgImg"]
    brWidth  = setting["brWidth"]
    brHeith  = setting["brHeith"]
    brNum  = setting["brNum"]
    
    c.execute(f"UPDATE galaxy SET horLine={horLine} WHERE ROWID={id}")
    c.execute(f"UPDATE galaxy SET sound={sound} WHERE ROWID={id}")
    c.execute(f"UPDATE galaxy SET music={music} WHERE ROWID={id}")
    c.execute(f"UPDATE galaxy SET bgImg={bgImg} WHERE ROWID={id}")
    c.execute(f"UPDATE galaxy SET brWidth={brWidth} WHERE ROWID={id}")
    c.execute(f"UPDATE galaxy SET brHeith={brHeith} WHERE ROWID={id}")
    c.execute(f"UPDATE galaxy SET brNum={brNum} WHERE ROWID={id}")
    conn.commit()

def setScore(score):
    result = getScore()
    if result != None:
        if score > result:
            updateScore(1, score)
    else:
        insertScore(score)
    
#==========RESETTING===========
def resetScore():
    updateScore(1, 0)
    
def resetSetting():
    id = 1
    setting = {}
    setting["horLine"] = False
    setting["sound"] = True
    setting["music"] = True
    setting["bgImg"] = True
    setting["brWidth"] = 150
    setting["brHeith"] = 50
    setting["brNum"] = 9
    result = getSetting()
    if result != None:
        updateSetting(id, setting)
    else:
        insertSetting(setting)
        
#==========DISPLAING SCORE===========        
def desplayScore():
    result = getScore()
    print(result)

def desplaySetting():
    result = getSetting()
    print(result)
    
if __name__=='__main__':
#    createScoreTable()
#    createGalaxyTable()
#    insertScore(555)
#    resetSetting()
#    desplayScore()
#    desplaySetting()
#    setScore(57)
#    updateSetting()
#    resetScore(1)
#    resetSetting(1)
#    print(getScore())
#    settingContext = getSetting()
#    settingContext["horLine"] = True
#    settingContext["sound"] = False
#    settingContext["bgImg"] = False 
#    settingContext["brWidth"] = 160
#    settingContext["brHeith"] = 50
#    settingContext["brNum"] = 7 
#    print(settingContext)     
#    updateSetting(settingContext)
#    desplaySetting()
           
    pass
