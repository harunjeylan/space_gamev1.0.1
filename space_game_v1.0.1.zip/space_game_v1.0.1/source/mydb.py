import sqlite3, os
#import pandas as pd
#=====CONNECTING WITH DATABASE=======
#conn = sqlite3.connect('student.db')
#c = conn.cursor()

#=========CREATING TABLE=========
def connect():
    if __name__ == '__main__':
        conn = sqlite3.connect(os.path.join('spaceGame.db'))
    else:
        conn = sqlite3.connect(os.path.join('source','spaceGame.db'))
    c = conn.cursor()
    return conn, c
    
def createTable():
    conn, c = connect()
    c.execute("CREATE TABLE HighScore (highScore  int)")
    conn.commit()

#==========INSERTING SCORE===========
def insert(score):
    conn, c = connect()
    c.execute(f"INSERT INTO HighScore(highScore) values({score})")
    conn.commit()
    
#==========GATING SCORE===========
def getScore(*args, **kargs):
    conn, c = connect()
    x = c.execute("SELECT ROWID, * FROM HighScore")
    result = None
    #print(kargs)
    if args == () or args[0] == 1:
        result = x.fetchone()
    elif args[0] > 1:
        result = x.fetchmany(args[0])
    elif kargs['all'] == True:
        result = x.fetchall()
    conn.commit()
    return result
    
#==========UPDATING SCORE===========
def update(id, score):
    conn, c = connect()
    c.execute(f"UPDATE HighScore SET HighScore={score} WHERE ROWID={id}")
    conn.commit()

def setScore(score):
    result = getScore()
    if result != None:
        if score > result[1]:
            update(result[0], score)
    else:
        insert(score)
    
#==========DELETING SCORE===========
def deleteScore(id):
    conn, c = connect()
    c.execute(f"DELETE FROM HighScore WHERE ROWID={id}")
    conn.commit()
    

        
#==========DISPLAING SCORE===========        
def desplay():
    result = getScore()
    print(result)
    
if __name__=='__main__':
#    createTable()
#    insert(555)
#    desplay()
#    setScore(57)
#    desplay()
#    setScore(66)
#    desplay()
#    deleteScore(1)
    print(getScore())
    pass
