#THIS SIMPLE HUBO ON GALAXY GAME IS MADE BY HARUN JEYLAN 
#ASTU 2-YEAR ELECTONICS AND COMUNICATION-ENGINEERING 
# 22/jun/2022 EC
# space game v-1.0.1

#===========IMPORTIMG=============
import pygame, sys, os
from pygame.locals import *
import numpy as np
import random
from source.mydb import getScore, setScore
#========================
pygame.init() #INIT PYGAME

#======CONISTANTS=======
WIDTH = 480 #width of window
HIGHT = 800 #hight of window
FPS = 60 #Defalt 50
MIN_SPEED_Y = 5 #Defalt 5
MAX_SPEED_Y = 15 #Defalt 15
SPEED_X = 50 #Defalt 50

SCORE_MALT = 1 #Defalt 1
SCORE_DUR = 5 #Defalt 5
LAVEL_DUR = 100 #Defalt 100
BRIDG_MAXWIDTH = 180 #Defalt 150
BRIDGHIGHT = 50 #Defalt 50
BRIDG_NUM = 9 #Defalt 9

SHOW_HOR_LINE =False #Defalt False
USE_BG_IMG = True #Defalt True
USE_SOUND = True #Defalt True
#===========FONT SIZE=========
BASICFONTSIZE = 20
BUTTONFONTSIZE = 30
TITLEFONTSIZE = 50
NORMALFONTSIZE = 25
#========================

#======COLORS========
WHITE = (255,255,255)
GREEN = (0,255,0)
BLUE = (0,0,255)
RED = (255,0,0)
BLACK = (0,0,0)
YELLOW = (255, 255, 0)
BRIGHTBLUE =  (  0,  50, 255)
DARKTURQUOISE = (  3,  54,  73)

def rondomColorpicker():
    r = random.randint(50,255)
    g = random.randint(50,255)
    b = random.randint(50,255)
    return np.array([r,g,b], dtype=np.int32)
    
COLORS = np.array([rondomColorpicker() for i in range(100)], dtype=np.int32)
TILECOLOR = GREEN
TEXTCOLOR = WHITE
BUTTONCOLOR = WHITE
BGCOLOR = DARKTURQUOISE
BACKGROUND = pygame.image.load(os.path.join('image','bg1.jpg'))
#========================================

#=========== VOICE =========
galaxy_voice = pygame.mixer.Sound(os.path.join('sound','galaxy.wav'))
gameover_voice = pygame.mixer.Sound(os.path.join('sound','gameover_voice.wav'))
begin_voice = pygame.mixer.Sound(os.path.join('sound','begin.wav'))
restart_voice = pygame.mixer.Sound(os.path.join('sound','restart.wav'))
#========================================

#===========SETUPING=========
WIN = pygame.display.set_mode((WIDTH,HIGHT))
pygame.display.set_caption('my game')

def setup():
    global CENTER_WIN_X, CENTER_WIN_Y, INITIAL_POINT_X, INITIAL_POINT_Y
    global POS_POINT_LIST_X, ACTIVE_BRIDG_POINT
    global WIDTH, HIGHT, INITIAL_POINT_Y, BRIDG_NUM, BRIDG_MAXWIDTH, BRIDGHIGHT, SPEED_X
    CENTER_WIN_X = WIDTH//2 + WIDTH%2
    CENTER_WIN_Y = HIGHT//2 + HIGHT%2
    INITIAL_POINT_X = CENTER_WIN_X
    INITIAL_POINT_Y = HIGHT//4

    initial = 0 - (BRIDG_MAXWIDTH * BRIDG_NUM - WIDTH)/2
    final = WIDTH + (BRIDG_MAXWIDTH * BRIDG_NUM - WIDTH)/2
    POS_POINT_LIST_X = np.linspace(initial, final,BRIDG_NUM+1, dtype=np.int32)
    ACTIVE_BRIDG_POINT = POS_POINT_LIST_X[BRIDG_NUM//2]
    while (HIGHT - INITIAL_POINT_Y) % BRIDGHIGHT != 0:
        BRIDGHIGHT -= 1
    while BRIDG_MAXWIDTH % SPEED_X != 0:
        SPEED_X -= 1
#========================================

#===========MAIN FUNCTION=========
def main():
    setup()
    global CENTER_WIN_X, CENTER_WIN_Y, INITIAL_POINT_X, INITIAL_POINT_Y
    global POS_POINT_LIST_X, ACTIVE_BRIDG_POINT
    
    SPEED = MIN_SPEED_Y
    clock = pygame.time.Clock()
    point  = BRIDG_NUM//2
    active = True
    SCORE = [0, 0]
    LAVEL = 1
    PosX = np.array([BRIDG_NUM//2, BRIDG_NUM//2+1], dtype=np.int32)
    line_list_y = np.arange(INITIAL_POINT_Y, HIGHT + (BRIDGHIGHT * 4), BRIDGHIGHT, dtype=np.int32)
    BRIDG_LIST = [Bridg() for i in range(len(line_list_y))]
    intialbridge = Bridg()
    intialbridge.setBridg(PosX, (INITIAL_POINT_Y, HIGHT))
    intialbridge.PosX = PosX
    #---------- main loop ---------------
    while True:
        clock.tick(FPS)
        draw_window()
        textSurf, textRect = makeText(f"LAVEL: {LAVEL}; SCORE: {SCORE[0]}", TEXTCOLOR, BASICFONTSIZE)
        textRect.topleft = (10,10)
        WIN.blit(textSurf, textRect)
        point = eventHandeler(point = point)
        
        if POS_POINT_LIST_X[point] < ACTIVE_BRIDG_POINT:
            POS_POINT_LIST_X += SPEED_X
        elif POS_POINT_LIST_X[point] > ACTIVE_BRIDG_POINT:
            POS_POINT_LIST_X -= SPEED_X
        
        ind1 = line_list_y < HIGHT + BRIDGHIGHT * 4        
        ind2 = line_list_y >= HIGHT + BRIDGHIGHT * 4
        line_list_y[ind2] =  INITIAL_POINT_Y
        line_list_y[ind1] +=  SPEED 
        
        BRIDG_LIST, intialbridge, active, PosX = createBridge(BRIDG_LIST, line_list_y, intialbridge, active, PosX)
        
        if SHOW_HOR_LINE:
            for i in range(len(line_list_y)):
                y = line_list_y[i]
                point1 = calculatePointXY(POS_POINT_LIST_X[0], y)
                point2 = calculatePointXY(POS_POINT_LIST_X[-1], y)
                pygame.draw.line(WIN, WHITE, point1, point2, 1)
            
        for x in POS_POINT_LIST_X:
            pygame.draw.line(WIN, WHITE, (INITIAL_POINT_X, INITIAL_POINT_Y), (x,HIGHT), 1)
        
        pygame.draw.polygon(WIN, BLACK, ((INITIAL_POINT_X, HIGHT-100-5), (INITIAL_POINT_X+25+5, HIGHT-50+5), (INITIAL_POINT_X-25-5, HIGHT-50+5)))
        if active:
            pygame.draw.polygon(WIN, WHITE, ((INITIAL_POINT_X, HIGHT-100), (INITIAL_POINT_X+25, HIGHT-50), (INITIAL_POINT_X-25, HIGHT-50)))            
            SPEED += SCORE[0]//(LAVEL_DUR * LAVEL) if SPEED <= MAX_SPEED_Y else 0
            LAVEL += SCORE[0]//(LAVEL_DUR * LAVEL)
            SCORE[1] += 1
            
            if SCORE[1] >= SCORE_DUR:
                SCORE[0] +=  SCORE_MALT
                SCORE[1] = 0
        else:
           pygame.draw.polygon(WIN, RED, ((INITIAL_POINT_X, HIGHT-100), (INITIAL_POINT_X+25, HIGHT-50), (INITIAL_POINT_X-25, HIGHT-50)))  
           break
        pygame.display.update()
        
    setScore(SCORE[0])
    if USE_SOUND:
        gameover_voice.play()
    startGameRect, quitRect = displayText("GAME OVER", "RESTART", SCORE[0])
    while True: eventHandeler(start_rect = startGameRect, quit_rect = quitRect, voice = restart_voice)
#========================================

#==================DROWING WINDOW=================
def draw_window():   
    if USE_BG_IMG:
        WIN.blit(BACKGROUND, (0, 0))
    else:
        WIN.fill(BGCOLOR)
#========================================

#========================================    
def calculatePointXY(PosPointX, PointY):
    exactPoint = np.array([0, PointY], dtype=np.int32)
    if PosPointX < CENTER_WIN_X:
        exactPoint[0] =  INITIAL_POINT_X-((INITIAL_POINT_X - PosPointX)*(PointY-INITIAL_POINT_Y)/(HIGHT-INITIAL_POINT_Y))
    else:
        exactPoint[0] =  INITIAL_POINT_X+((PosPointX-INITIAL_POINT_X)*(PointY-INITIAL_POINT_Y)/(HIGHT-INITIAL_POINT_Y))
    return exactPoint
#========================================

#========================================    
def chengePosX(PosX):
    if PosX[0] ==  0 and PosX[1] ==  1:
        PosX =  random.choice([PosX, PosX + 1])
    elif PosX[0] ==  BRIDG_NUM-1 and PosX[1] ==  BRIDG_NUM:
        PosX =  random.choice([PosX-1, PosX])
    else:
        PosX =  random.choice([PosX - 1, PosX, PosX + 1])
    return PosX
#========================================

#========================================     
def exactPointXY(PosX, exactPointY):  
    exactPoints = np.zeros((4, 2), dtype = np.int32)
    posPoint_x1 = POS_POINT_LIST_X[PosX[0]]
    posPoint_x2 = POS_POINT_LIST_X[PosX[1]]
    exactPoints[0] = calculatePointXY(posPoint_x1, exactPointY[0])
    exactPoints[1] = calculatePointXY(posPoint_x2, exactPointY[0])
    exactPoints[2] = calculatePointXY(posPoint_x2, exactPointY[1])
    exactPoints[3] = calculatePointXY(posPoint_x1, exactPointY[1])
    return exactPoints
#========================================

#===============BRIDG CLASS=================    
class Bridg:
    def __init__(self):
        self.points = np.zeros((4, 2),  dtype=np.int32)
        self.color = (0,200,100)
        self.PosX = np.array([0,0],  dtype=np.int32)    
    def setBridg(self, PosX, exactPointY):  
        self.PosX = chengePosX(PosX)
        self.points  = exactPointXY(self.PosX, exactPointY)
        colorIndex = random.randint(0,len(COLORS)-1)
        self. color = COLORS[colorIndex]
        return  self.PosX
    def updateBridg(self, exactPointY):
        self.points = exactPointXY(self.PosX, exactPointY)
    def getPoints(self):
        return self.points
    def getColor(self):
         return  self.color 
#========================================

#========================================        
def makeText(text, color, fontSize):
    BASICFONT = pygame.font.Font(os.path.join('source','freesansbold.ttf'), fontSize, )
    textSurf = BASICFONT.render(text, True, color)
    textRect = textSurf.get_rect()
    return (textSurf, textRect)
#========================================

#========================================                         
def createBridge(BRIDG_LIST, line_list_y, intialbridge, active, PosX):
        active = False
        for i in range(len(BRIDG_LIST)):            
            if line_list_y[i] == INITIAL_POINT_Y and i%2==1:
                 PosX =  BRIDG_LIST[i].setBridg(PosX, (INITIAL_POINT_Y, INITIAL_POINT_Y))
            elif line_list_y[i-3] > line_list_y[i]: 
                 BRIDG_LIST[i].updateBridg((INITIAL_POINT_Y, line_list_y[i]))
            else:
                 BRIDG_LIST[i].updateBridg((line_list_y[i-3] , line_list_y[i]))

            points = BRIDG_LIST[i].getPoints()
            color = BRIDG_LIST[i].getColor()
            if intialbridge.getPoints()[0,1] < HIGHT and i==0:
                if BRIDG_LIST[0].getPoints()[3,1] <= INITIAL_POINT_Y + BRIDGHIGHT*2:
                    intialbridge.updateBridg((INITIAL_POINT_Y , HIGHT))
                else:
                    intialbridge.updateBridg((line_list_y[-2] , HIGHT))                
                points = intialbridge.getPoints()
                                  
            polygon = pygame.draw.polygon(WIN, color, points)        
            if polygon.collidepoint(INITIAL_POINT_X, HIGHT-75) or polygon.collidepoint(INITIAL_POINT_X, HIGHT-50):
                 active = True              
                 
        return BRIDG_LIST, intialbridge, active, PosX
#========================================

#========================================
def setCenter(myRect, xPos, yPos):
    myRect.centery = yPos
    myRect.centerx = xPos
#========================================

#========================================    
def displayText(gameTitle, startGame, newScore = None):
    draw_window()
    highScore = getScore()
    highScore =  highScore[1] if highScore != None else 0
    
    titleSerf, titleRect = makeText(f"{gameTitle}", TILECOLOR, TITLEFONTSIZE) 
    haghScoreSurf, haghScoreRect = makeText(f"HIGH SCORE: {highScore}", TEXTCOLOR, NORMALFONTSIZE) 
    scoreSerf, scoreRect = makeText(f"YOUR SCORE: {newScore}", TEXTCOLOR, NORMALFONTSIZE) 
    startGameSerf, startGameRect = makeText(f"{startGame}", BUTTONCOLOR, BUTTONFONTSIZE)
    quitSerf, quitRect = makeText("QUIT", BUTTONCOLOR, BUTTONFONTSIZE)
    
    setCenter(titleRect, CENTER_WIN_X, INITIAL_POINT_Y + 60)
    setCenter(haghScoreRect, CENTER_WIN_X, INITIAL_POINT_Y+120)
    pygame.draw.line(WIN, WHITE, (50, INITIAL_POINT_Y+180), (WIDTH-50,INITIAL_POINT_Y+180), 1)
    setCenter(scoreRect, CENTER_WIN_X, INITIAL_POINT_Y+240)    
    setCenter(startGameRect, CENTER_WIN_X,INITIAL_POINT_Y + 300)
    setCenter(quitRect, CENTER_WIN_X,INITIAL_POINT_Y + 360)

    WIN.blit(titleSerf, titleRect)
    WIN.blit(haghScoreSurf, haghScoreRect)
    if newScore is not None: WIN.blit(scoreSerf, scoreRect)
    WIN.blit(startGameSerf, startGameRect)
    WIN.blit(quitSerf, quitRect)
    pygame.display.update()
    return startGameRect, quitRect
#========================================

#========================================            
def eventHandeler(*args, **kargs):    
    for event in pygame.event.get():
        if event == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == MOUSEBUTTONUP:
            if "start_rect" in kargs and "quit_rect" in kargs:
                if kargs["quit_rect"].collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()
                elif kargs["start_rect"].collidepoint(event.pos):
                    if USE_SOUND:
                        kargs["voice"].play()
                    main()
                    
            elif "point" in kargs:               
                if event.pos[0] >  CENTER_WIN_Y  and kargs["point"] < BRIDG_NUM -1:
                    kargs["point"]  += 1
                elif event.pos[0] < CENTER_WIN_Y   and kargs["point"] > 0:
                    kargs["point"]  -= 1                                            
    if "point" in kargs:  return  kargs["point"]    
#========================================

#========================================
if __name__=='__main__':
    setup()
    draw_window()
    if USE_SOUND:
        galaxy_voice.play()
    startGameRect, quitRect = displayText("GALAXY", "PLAY")
    while True: eventHandeler(start_rect = startGameRect, quit_rect = quitRect, voice = begin_voice)